#/bin/bash

g++ -o spline_solve spline_solve.cpp -lginac --std=c++11
