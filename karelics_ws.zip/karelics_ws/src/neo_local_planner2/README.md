# neo_local_planner2
Potential field based local planner for ROS-2

Please find our documentations in https://docs.neobotix.de/display/ROSPKGS/neo_local_planner