This simulation package provides a quick and easy way to try out the autonomous mobile robots from Neobotix in ROS-2. It comes with the most commonly used configuration but is open for any kind of modification.

Please find our documentations in https://docs.neobotix.de/display/R2/ROS+2-Simulation